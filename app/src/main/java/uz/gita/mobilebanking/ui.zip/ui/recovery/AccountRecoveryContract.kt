package uz.gita.mobilebanking.ui.recovery

class AccountRecoveryContract {

    data class State(
        val isBackButtonEnabled: Boolean = true,
        val isSendButtonEnabled: Boolean = true,
        val isProgress: Boolean = false
    )

    sealed class Event {
        data class Send(val phoneNumber: String) : Event()
        object OnBackPressed : Event()
    }

}