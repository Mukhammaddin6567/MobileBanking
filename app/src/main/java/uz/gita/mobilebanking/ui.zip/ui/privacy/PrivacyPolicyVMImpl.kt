package uz.gita.mobilebanking.ui.privacy

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import timber.log.Timber
import javax.inject.Inject

@HiltViewModel
class PrivacyPolicyVMImpl @Inject constructor(
    private val privacyPolicyDirection: PrivacyPolicyDirection
) : ViewModel(), PrivacyPolicyVM {

    private var _state = MutableStateFlow(PrivacyPolicyContract.State())
    override val state: StateFlow<PrivacyPolicyContract.State> = _state.asStateFlow()

    override fun onEvent(event: PrivacyPolicyContract.Event) {
        when (event) {
            PrivacyPolicyContract.Event.CHECK -> {
                reduce { it.copy(buttonAcceptStatus = !it.buttonAcceptStatus) }
            }
            PrivacyPolicyContract.Event.ACCEPT -> {
                Timber.d("onEvent: ACCEPT")
                privacyPolicyDirection.navigateToSignInScreen()
            }
        }
    }

    private fun reduce(content: (old: PrivacyPolicyContract.State) -> PrivacyPolicyContract.State) {
        val oldState = _state.value
        val newState = content(oldState)
        _state.value = newState
    }
}