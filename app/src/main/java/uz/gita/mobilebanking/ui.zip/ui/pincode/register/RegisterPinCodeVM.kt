package uz.gita.mobilebanking.ui.pincode.register

import kotlinx.coroutines.flow.StateFlow

interface RegisterPinCodeVM {

    val state: StateFlow<RegisterPinCodeContract.State>

    fun onEvent(event: RegisterPinCodeContract.Event)

}