package uz.gita.mobilebanking.utils.customui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import uz.gita.mobilebankingMBF.R

@Composable
fun AuthButton(
    onClick: () -> Unit,
    modifier: Modifier,
    enabled: Boolean,
    text: Int,
) {
    Button(
        onClick = { onClick.invoke() },
        modifier = modifier
            .height(48.dp)
            .fillMaxWidth(),
        enabled = enabled,
        shape = RoundedCornerShape(8.dp),
        colors = ButtonDefaults.buttonColors(
            backgroundColor = when (enabled) {
                false -> colorResource(id = R.color.button_disabled)
                else -> colorResource(id = R.color.button_enabled)
            }
        )
    ) {
        Text(
            text = stringResource(id = text),
            color = when (enabled) {
                false -> colorResource(id = R.color.text_light_gray)
                else -> colorResource(id = R.color.text_white)
            },
            style = MaterialTheme.typography.button
        )
    }
}