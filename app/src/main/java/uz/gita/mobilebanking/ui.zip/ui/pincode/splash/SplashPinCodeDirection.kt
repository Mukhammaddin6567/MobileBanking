package uz.gita.mobilebanking.ui.pincode.splash

interface SplashPinCodeDirection {


    fun navigateToMainScreen()

}