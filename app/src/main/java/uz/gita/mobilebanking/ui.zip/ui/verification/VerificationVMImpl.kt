package uz.gita.mobilebanking.ui.verification

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import uz.gita.mobilebanking.data.local.model.auth.*
import uz.gita.mobilebanking.domain.usecase.verification.VerificationUC
import uz.gita.mobilebanking.utils.toPhoneNumberUI
import javax.inject.Inject

@HiltViewModel
class VerificationVMImpl @Inject constructor(
    private val verificationUC: VerificationUC,
    private val direction: VerificationDirection
) : ViewModel(), VerificationVM {

    private var _state = MutableStateFlow(VerificationContract.State())
    override val state: StateFlow<VerificationContract.State> = _state.asStateFlow()
    private var timer: Long = _state.value.timer
    private var job: Job? = null
    private var data: SignUpData? = null

    init {
        initTimer()
    }

    override fun onEvent(event: VerificationContract.Event) {
        when (event) {
            is VerificationContract.Event.OnBackPressed -> {
                job?.cancel()
                direction.popBackStack()
            }
            is VerificationContract.Event.Retry -> {
                viewModelScope.launch { reduce { it.copy(timerStatus = true) } }
                initTimer()
            }
            is VerificationContract.Event.Filled -> {
                viewModelScope.launch { reduce { it.copy(acceptButtonStatus = true) } }
            }
            is VerificationContract.Event.UnFilled -> {
                viewModelScope.launch { reduce { it.copy(acceptButtonStatus = false) } }
            }
            is VerificationContract.Event.ActionKeyboard -> {
                if (_state.value.errorStatus) reduce { it.copy(errorStatus = false) }
            }
            is VerificationContract.Event.OnRegister -> {
                stopTimer()
                reduce {
                    it.copy(
                        isKeyboardEnabled = false,
                        acceptButtonStatus = false,
                        progressStatus = true
                    )
                }
                Timber.d("code: ${event.code}")
                job = verificationUC
                    .signUpVerify(data = VerificationData(code = event.code))
                    .onEach { resultData ->
                        reduce { it.copy(progressStatus = false, isKeyboardEnabled = true) }
                        resultData.onSuccess {
                            direction.navigateToRegisterPinCodeScreen()
                            setDefaultState()
                        }
                        resultData.onText {
                            reduce {
                                it.copy(
                                    message = message,
                                    errorStatus = true,
                                    timerStatus = false
                                )
                            }
                        }
                        resultData.onResource {
                            reduce {
                                it.copy(
                                    resourceId = resourceId,
                                    errorStatus = true,
                                    timerStatus = false
                                )
                            }
                        }
                    }
                    .launchIn(viewModelScope)
            }
        }
    }

    override fun initData(data: SignUpData) {
        this.data = data
        viewModelScope.launch { reduce { it.copy(phoneNumber = toPhoneNumberUI(data.phoneNumber)) } }
    }

    private fun initTimer() {
        if (timer == 0L) timer = 60000L
        viewModelScope.launch {
            while (timer != 0L) {
                delay(1000)
                reduce { it.copy(timer = timer) }
                timer -= 1000L
                if (timer == 0L) reduce { it.copy(timerStatus = false) }
            }
        }
    }

    private fun stopTimer() {
        timer = 0
    }

    private fun reduce(content: (old: VerificationContract.State) -> VerificationContract.State) {
        val oldState = _state.value
        val newState = content(oldState)
        _state.value = newState
    }

    private fun setDefaultState() {
        _state.value = VerificationContract.State()
    }

}