package uz.gita.mobilebanking.ui.signin

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SignInVMImpl @Inject constructor(
    private val signInDirection: SignInDirection
) : ViewModel(), SignInVM {

    private var _state = MutableStateFlow(SignInContract.State())
    override val state: StateFlow<SignInContract.State> = _state.asStateFlow()


    override fun onEvent(event: SignInContract.Event) {
        when (event) {
            is SignInContract.Event.Enter -> {
                reduce {
                    it.copy(
                        isProgress = true,
                        enterButtonEnabled = false,
                        signUpButtonEnabled = false,
                        forgotPasswordEnabled = false
                    )
                }
                viewModelScope.launch {
                    delay(2000)
                    setDefaultState()
                }
            }
            is SignInContract.Event.ForgotPassword -> {
                signInDirection.navigateToAccountRecoveryScreen()
                setDefaultState()
            }
            is SignInContract.Event.Register -> {
                signInDirection.navigateToSignUpScreen()
                setDefaultState()
            }
        }
    }

    private fun reduce(content: (old: SignInContract.State) -> SignInContract.State) {
        val oldState = _state.value
        val newState = content(oldState)
        _state.value = newState
    }

    private fun setDefaultState() {
        _state.value = SignInContract.State()
    }

}