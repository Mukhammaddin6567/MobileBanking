package uz.gita.mobilebanking.ui.signin

interface SignInDirection {

    fun navigateToAccountRecoveryScreen()

    fun navigateToSignUpScreen()

//    fun navigateToVerificationScreen(phoneNumber: String)

}