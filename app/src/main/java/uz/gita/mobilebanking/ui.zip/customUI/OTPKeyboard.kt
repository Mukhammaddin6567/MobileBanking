package uz.gita.mobilebanking.utils.customui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebankingMBF.R

@Composable
fun OTPKeyboard(
    numberOnClick: (digit: Int) -> Unit,
    clearOnClick: () -> Unit,
    backSpaceOnClick: () -> Unit,
    modifier: Modifier,
) {
    Column(
        modifier = modifier
            .background(color = colorResource(id = R.color.background_otp_keyboard))
    ) {
        Spacer(modifier = Modifier.padding(top = 8.dp))
        Row(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp, end = 8.dp),
            /*verticalAlignment = Alignment.CenterVertically*/
        ) {
            NumberButton(onClick = numberOnClick, number = 1, modifier = Modifier.weight(1f))
            NumberButton(onClick = numberOnClick, number = 2, modifier = Modifier.weight(1f))
            NumberButton(onClick = numberOnClick, number = 3, modifier = Modifier.weight(1f))
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp, end = 8.dp),
            /*verticalAlignment = Alignment.CenterVertically*/
        ) {
            NumberButton(onClick = numberOnClick, number = 4, modifier = Modifier.weight(1f))
            NumberButton(onClick = numberOnClick, number = 5, modifier = Modifier.weight(1f))
            NumberButton(onClick = numberOnClick, number = 6, modifier = Modifier.weight(1f))
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .padding(start = 8.dp, end = 8.dp),
            /*verticalAlignment = Alignment.CenterVertically*/
        ) {
            NumberButton(onClick = numberOnClick, number = 7, modifier = Modifier.weight(1f))
            NumberButton(onClick = numberOnClick, number = 8, modifier = Modifier.weight(1f))
            NumberButton(onClick = numberOnClick, number = 9, modifier = Modifier.weight(1f))
        }

        Row(
            modifier = Modifier
                .padding(start = 8.dp, end = 8.dp)
                .weight(1f),
            /*verticalAlignment = Alignment.CenterVertically*/
        ) {
            ActionButton(
                onClick = clearOnClick,
                modifier = Modifier.weight(1f),
                icon = R.drawable.ic_clear
            )
            NumberButton(onClick = numberOnClick, number = 0, modifier = Modifier.weight(1f))
            ActionButton(
                onClick = backSpaceOnClick,
                modifier = Modifier.weight(1f),
                icon = R.drawable.ic_backspace
            )
        }
        Spacer(modifier = Modifier.padding(bottom = 8.dp))
    }
}

@Composable
private fun NumberButton(
    onClick: (digit: Int) -> Unit,
    number: Int,
    modifier: Modifier
) {
    TextButton(
        colors = ButtonDefaults.buttonColors(
            backgroundColor = colorResource(id = R.color.background_otp_keyboard_number_button)
        ),
        onClick = { onClick.invoke(number) },
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp),
        shape = RoundedCornerShape(4.dp)
    ) {
        Text(
            text = "$number",
            style = MaterialTheme.typography.body1
        )
    }
}

@Composable
private fun ActionButton(
    onClick: () -> Unit,
    modifier: Modifier,
    icon: Int
) {
    Image(
        painter = painterResource(id = icon),
        contentDescription = "",
        contentScale = ContentScale.Inside,
        modifier = modifier
            .fillMaxSize()
            .padding(8.dp)
            .background(color = colorResource(id = R.color.background_otp_keyboard_action_button))
            .clickable { onClick.invoke() }
    )
}

@Preview
@Composable
private fun OTPKeyboardPreview() {
    MobileBankingTheme {
        Surface() {
            OTPKeyboard(
                numberOnClick = {},
                clearOnClick = {},
                backSpaceOnClick = {},
                modifier = Modifier
            )
        }
    }
}
