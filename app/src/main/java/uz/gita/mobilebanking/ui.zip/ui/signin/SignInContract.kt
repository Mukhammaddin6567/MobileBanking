package uz.gita.mobilebanking.ui.signin

class SignInContract {

    data class State(
        val isProgress: Boolean = false,
        val isPhoneNumberError: Boolean = false,
        val isPasswordError: Boolean = false,
        val enterButtonEnabled: Boolean = true,
        val signUpButtonEnabled: Boolean = true,
        val forgotPasswordEnabled: Boolean = true
    )

    sealed class Event {
        object Register : Event()
        object ForgotPassword : Event()
        data class Enter(
            val phoneNumber: String,
            val password: String
        ) : Event()
    }

}