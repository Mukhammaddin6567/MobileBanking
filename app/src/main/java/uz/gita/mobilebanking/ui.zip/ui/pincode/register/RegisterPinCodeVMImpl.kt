package uz.gita.mobilebanking.ui.pincode.register

import android.os.Build
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber
import uz.gita.mobilebanking.domain.usecase.pincode.PinCodeUC
import uz.gita.mobilebankingMBF.R
import javax.inject.Inject

@HiltViewModel
class RegisterPinCodeVMImpl @Inject constructor(
    private val useCase: PinCodeUC,
    private val direction: RegisterPinCodeDirection
) : ViewModel(), RegisterPinCodeVM {

    private var _state = MutableStateFlow(RegisterPinCodeContract.State())
    override val state: StateFlow<RegisterPinCodeContract.State> = _state.asStateFlow()

    override fun onEvent(event: RegisterPinCodeContract.Event) {
        Timber.d("event: $event")
        when (event) {
            is RegisterPinCodeContract.Event.Checked -> {
                viewModelScope.launch {
                    useCase
                        .savePinCode(code = event.code)
                        .collectLatest {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) direction.navigateToFingerPrintScreen()
                            else direction.navigateToMainScreen()
                        }
                }
            }
            is RegisterPinCodeContract.Event.Skip -> direction.navigateToMainScreen()
            is RegisterPinCodeContract.Event.Filled -> reduce { it.copy(textSkip = R.string.text_ready) }
            else -> reduce { it.copy(textSkip = R.string.text_skip) }
        }
    }

    private fun reduce(content: (old: RegisterPinCodeContract.State) -> RegisterPinCodeContract.State) {
        val oldValue = _state
        val newValue = content(oldValue.value)
        _state.value = newValue
    }
}