package uz.gita.mobilebanking.ui.splash

interface SplashDirection {

    fun navigateToSplashPinCodeScreen()
    fun navigateToLanguageScreen()
    fun navigateToSignInScreen()

}