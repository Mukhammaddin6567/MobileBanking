package uz.gita.mobilebanking.ui.pincode.splash

import uz.gita.mobilebankingMBF.R

class SplashPinCodeContract {

    data class State(
        val isError: Boolean = false,
        val isFingerPrint: Boolean = false,
        val textPinCode: Int = R.string.text_pin_code_enter
    )

    sealed class Event {
        data class EnterCode(val code: String) : Event()
        object FingerPrint : Event()
    }

    enum class SideEffect {
        FINGER_PRINT
    }

}