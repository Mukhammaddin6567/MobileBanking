package uz.gita.mobilebanking.ui.language

class LanguageContract {

    sealed class Event {
        data class AcceptLanguage(val language: String) : Event()
    }

    data class State(
        val languages: List<String> = emptyList(),
        val currentLanguage: String
    )

    sealed class SideEffect {
        data class SetLanguage(val language: String) : SideEffect()
    }

    /*sealed class SideEffect {
        object NavigateToLoginScreen : SideEffect()
        // to be continued ...
    }*/

}