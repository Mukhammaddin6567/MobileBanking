package uz.gita.mobilebanking.ui.signup

import kotlinx.coroutines.flow.StateFlow

interface SignUpVM {

    val state: StateFlow<SignUpContract.State>

    fun onEvent(event: SignUpContract.Event)

    fun sideEffect(sideEffect: (sideEffect: SignUpContract.SideEffect) -> Unit)

}
