package uz.gita.mobilebanking.ui.changepassword

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.PasswordTrailingIcon
import uz.gita.mobilebanking.utils.customui.AuthButton
import uz.gita.mobilebanking.utils.customui.AuthOutlinedTextField
import uz.gita.mobilebanking.utils.customui.AuthTitle
import uz.gita.mobilebanking.utils.passwordVisualTransformation
import uz.gita.mobilebankingMBF.R

@Parcelize
class ChangePasswordScreen(override val screenKey: String = uniqueScreenKey) :
    ComposeScreen(id = "ChangePasswordScreen") {

    @Composable
    override fun Content() {

    }

}

@Composable
private fun ChangePasswordContent() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        var textNewPassword by remember { mutableStateOf("") }
        var newPasswordStatus by remember { mutableStateOf(false) }
        var newPasswordVisibility by remember { mutableStateOf(false) }
        var textConfirmPassword by remember { mutableStateOf("") }
        var confirmPasswordStatus by remember { mutableStateOf(false) }
        var confirmPasswordVisibility by remember { mutableStateOf(false) }
        val focusManager = LocalFocusManager.current

        AuthTitle(text = R.string.text_password_change)

        AuthOutlinedTextField(
            modifier = Modifier
                .padding(top = 64.dp),
            caption = R.string.text_password_new,
            value = textNewPassword,
            onValueChange = { password ->
                newPasswordStatus = password.length in 6..20
                textNewPassword = password
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Next
            ),
            visualTransformation = passwordVisualTransformation(newPasswordVisibility),
            trailingIcon = {
                PasswordTrailingIcon(
                    onIconClick = { newPasswordVisibility = !newPasswordVisibility },
                    passwordVisible = newPasswordVisibility
                )
            }
        )

        AuthOutlinedTextField(
            modifier = Modifier
                .padding(top = 16.dp),
            caption = R.string.text_password_confirm,
            value = textConfirmPassword,
            onValueChange = { password ->
                confirmPasswordStatus = password.length in 6..20
                textConfirmPassword = password
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = {
                focusManager.clearFocus()
            }),
            visualTransformation = passwordVisualTransformation(confirmPasswordVisibility),
            trailingIcon = {
                PasswordTrailingIcon(
                    onIconClick = { confirmPasswordVisibility = !confirmPasswordVisibility },
                    passwordVisible = confirmPasswordVisibility
                )
            }
        )

        val status = true
        when(status) {
            true -> CircularProgressIndicator(
                modifier = Modifier
                    .weight(1f)
                    .align(alignment = Alignment.CenterHorizontally)
                    .wrapContentHeight(align = Alignment.CenterVertically)
            )
            else -> Spacer(modifier = Modifier.weight(1f))
        }

        val authButtonStatus = newPasswordStatus && confirmPasswordStatus

        AuthButton(
            onClick = { /*TODO*/ },
            modifier = Modifier,
            enabled = authButtonStatus,
            text = R.string.text_password_save
        )

    }
}

@[Preview Composable]
private fun ChangePasswordPreview() {
    MobileBankingTheme {
        Surface() {
            ChangePasswordContent()
        }
    }
}