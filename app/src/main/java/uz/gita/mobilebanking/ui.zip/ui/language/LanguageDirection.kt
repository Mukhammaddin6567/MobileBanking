package uz.gita.mobilebanking.ui.language

interface LanguageDirection {

    fun navigateToPrivacyPolicyScreen()
    fun navigateToLoginScreen()

}