package uz.gita.mobilebanking.ui.verification

import kotlinx.coroutines.flow.StateFlow
import uz.gita.mobilebanking.data.local.model.auth.SignUpData

interface VerificationVM {

    val state: StateFlow<VerificationContract.State>

    fun onEvent(event: VerificationContract.Event)

    fun initData(data: SignUpData)

}