package uz.gita.mobilebanking.ui.signin

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.PasswordTrailingIcon
import uz.gita.mobilebanking.utils.customui.AuthButton
import uz.gita.mobilebanking.utils.customui.AuthOutlinedTextField
import uz.gita.mobilebanking.utils.customui.AuthTitle
import uz.gita.mobilebanking.utils.isPhoneNumber
import uz.gita.mobilebanking.utils.passwordVisualTransformation
import uz.gita.mobilebanking.utils.phoneNumberFilter
import uz.gita.mobilebankingMBF.R

@Parcelize
class SignInScreen(override val screenKey: String = uniqueScreenKey) :
    ComposeScreen(id = "SignInScreen") {

    @Composable
    override fun Content() {
        val viewModel: SignInVM = viewModel<SignInVMImpl>()
        SignInScreenContent(state = viewModel.state.collectAsState(), viewModel::onEvent)
    }
}

@Composable
fun SignInScreenContent(
    state: State<SignInContract.State>,
    event: (SignInContract.Event) -> Unit,
) {

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 32.dp)
    ) {
        var textPhoneNumber by remember { mutableStateOf("+998") }
        var textPassword by remember { mutableStateOf("") }
        var phoneNumberStatus by remember { mutableStateOf(false) }
        var passwordStatus by remember { mutableStateOf(false) }
        var passwordVisible by rememberSaveable { mutableStateOf(false) }
        val focusManager = LocalFocusManager.current

        AuthTitle(text = R.string.text_signin)

        AuthOutlinedTextField(
            modifier = Modifier.padding(top = 64.dp),
            caption = R.string.text_phone_number,
            value = textPhoneNumber,
            onValueChange = { phone ->
                if (phone.length > 13) return@AuthOutlinedTextField
                phoneNumberStatus = isPhoneNumber(phone)
                textPhoneNumber = phone
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Phone,
                imeAction = ImeAction.Next
            ),
            visualTransformation = { phoneNumberFilter(it) }
        )

        AuthOutlinedTextField(
            modifier = Modifier.padding(top = 8.dp),
            caption = R.string.text_password,
            value = textPassword,
            onValueChange = { password ->
                if (password.length > 20) return@AuthOutlinedTextField
                passwordStatus = password.length >= 6
                textPassword = password
            },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Password,
                imeAction = ImeAction.Done
            ),
            keyboardActions = KeyboardActions(onDone = {
                focusManager.clearFocus()
            }),
            visualTransformation = passwordVisualTransformation(passwordVisible),
            trailingIcon = {
                PasswordTrailingIcon(
                    onIconClick = { passwordVisible = !passwordVisible },
                    passwordVisible = passwordVisible
                )
            }
        )

        Text(
            modifier = Modifier
                .padding(top = 24.dp)
                .clickable {
                    if (state.value.forgotPasswordEnabled)
                        event(SignInContract.Event.ForgotPassword)
                },
            text = stringResource(id = R.string.text_password_forgot),
            style = MaterialTheme.typography.body1.copy(
                fontSize = 16.sp,
                color = colorResource(id = R.color.text_green),
                fontWeight = FontWeight.W500,
                lineHeight = 22.sp
            )
        )

        when {
            state.value.isProgress -> CircularProgressIndicator(
                modifier = Modifier
                    .weight(1f)
                    .align(alignment = Alignment.CenterHorizontally)
                    .wrapContentHeight(align = Alignment.CenterVertically)
            )
            else -> Spacer(modifier = Modifier.weight(1f))
        }

        val isButtonEnabled =
            phoneNumberStatus && passwordStatus && state.value.enterButtonEnabled

        AuthButton(
            onClick = {
                event(
                    SignInContract.Event.Enter(
                        phoneNumber = textPhoneNumber,
                        password = textPassword
                    )
                )
            },
            modifier = Modifier
                .padding(bottom = 16.dp),
            enabled = isButtonEnabled,
            text = R.string.text_enter
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                modifier = Modifier.padding(end = 8.dp),
                text = stringResource(id = R.string.text_signup_title),
                style = MaterialTheme.typography.body2
            )
            Text(
                modifier = Modifier
                    .clickable { if (state.value.signUpButtonEnabled) event(SignInContract.Event.Register) },
                text = stringResource(id = R.string.text_signup),
                style = MaterialTheme.typography.body1.copy(
                    fontSize = 16.sp,
                    color = colorResource(id = R.color.text_green),
                    fontWeight = FontWeight.W500,
                    lineHeight = 22.sp
                )
            )
        }
    }
}

@SuppressLint("UnrememberedMutableState")
@[Preview Composable]
fun SignInScreenPreview() {
    MobileBankingTheme {
        Surface(modifier = Modifier.fillMaxWidth()) {
            SignInScreenContent(state = mutableStateOf(SignInContract.State()), event = {})
        }
    }
}