package uz.gita.mobilebanking.ui.recovery

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import uz.gita.mobilebanking.data.local.model.auth.SignUpData
import javax.inject.Inject

@HiltViewModel
class AccountRecoveryVMImpl @Inject constructor(
    private val direction: AccountRecoveryDirection
) : ViewModel(), AccountRecoveryVM {

    private var _state = MutableStateFlow(AccountRecoveryContract.State())
    override val state: StateFlow<AccountRecoveryContract.State> = _state.asStateFlow()

    override fun onEvent(event: AccountRecoveryContract.Event) {
        when (event) {
            is AccountRecoveryContract.Event.Send -> {
                reduce {
                    it.copy(
                        isBackButtonEnabled = false,
                        isSendButtonEnabled = false,
                        isProgress = true
                    )
                }
                viewModelScope.launch {
                    delay(2000)
                    direction.navigateToVerificationScreen(
                        data = SignUpData(
                            "",
                            "",
                            "",
                            phoneNumber = event.phoneNumber
                        )
                    )
                    setDefaultState()
                }
            }
            is AccountRecoveryContract.Event.OnBackPressed -> {
                direction.popBackStack()
                setDefaultState()
            }
        }
    }

    private fun reduce(content: (old: AccountRecoveryContract.State) -> AccountRecoveryContract.State) {
        val oldState = _state.value
        val newState = content(oldState)
        _state.value = newState
    }

    private fun setDefaultState() {
        _state.value = AccountRecoveryContract.State()
    }
}