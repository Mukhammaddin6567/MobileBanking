package uz.gita.mobilebanking.ui.signup

import uz.gita.mobilebanking.data.local.model.auth.SignUpData

interface SignUpDirection {

    fun popBackStack()
    fun navigateToVerificationScreen(data: SignUpData)

}