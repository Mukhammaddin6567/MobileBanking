package uz.gita.mobilebanking.utils.customui

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.MaterialTheme
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Surface
import androidx.compose.material.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebankingMBF.R

@Composable
fun OTPTextFields(
    modifier: Modifier,
    length: Int,
    code: String,
    filled: () -> Unit,
    unFilled: () -> Unit,
    errorStatus: Boolean,
) {
    when (val currentPosition = code.length) {
        0 -> {
            unFilled.invoke()
            EmptyTextFields(
                modifier = modifier,
                length = length,
                errorStatus = errorStatus
            )
        }
        in 1 until length -> {
            unFilled.invoke()
            NotEmptyTextFields(
                modifier = modifier,
                currentPosition = currentPosition,
                length = length,
                code = code,
                errorStatus = errorStatus
            )
        }
        length -> {
            filled.invoke()
            FullTextFields(
                modifier = modifier,
                length = length,
                code = code,
                errorStatus = errorStatus
            )
        }
    }
}

@Composable
private fun EmptyTextFields(
    modifier: Modifier,
    length: Int,
    errorStatus: Boolean
) {
    Row(modifier = modifier) {
        OTPTextField(
            modifier = Modifier.weight(1f),
            backgroundColor = R.color.text_field_focused_indicator,
            errorStatus = errorStatus
        )
        repeat(length - 1) {
            OTPTextField(
                modifier = Modifier.weight(1f),
                backgroundColor = R.color.text_field_unfocused_indicator,
                errorStatus = errorStatus
            )
        }
    }
}

@Composable
private fun NotEmptyTextFields(
    modifier: Modifier,
    currentPosition: Int,
    length: Int,
    code: String,
    errorStatus: Boolean
) {
    Row(modifier = modifier) {
        repeat(currentPosition) { position ->
            OTPTextField(
                modifier = Modifier.weight(1f),
                value = "${code[position]}",
                backgroundColor = R.color.text_field_unfocused_indicator,
                errorStatus = errorStatus
            )
        }
        OTPTextField(
            modifier = Modifier.weight(1f),
            backgroundColor = R.color.text_field_focused_indicator,
            errorStatus = errorStatus
        )
        repeat(length - currentPosition - 1) {
            OTPTextField(
                modifier = Modifier.weight(1f),
                backgroundColor = R.color.text_field_unfocused_indicator,
                errorStatus = errorStatus
            )
        }
    }
}

@Composable
private fun FullTextFields(
    modifier: Modifier,
    length: Int,
    code: String,
    errorStatus: Boolean
) {
    Row(modifier = modifier) {
        repeat(length) { position ->
            OTPTextField(
                modifier = Modifier.weight(1f),
                value = "${code[position]}",
                backgroundColor = R.color.text_field_unfocused_indicator,
                errorStatus = errorStatus
            )
        }
    }
}

@Composable
private fun OTPTextField(
    modifier: Modifier,
    value: String = "",
    backgroundColor: Int = R.color.text_field_unfocused_indicator,
    errorStatus: Boolean
) {
    OutlinedTextField(
        value = value,
        enabled = false,
        onValueChange = {},
        modifier = modifier.padding(4.dp),
        singleLine = true,
        maxLines = 1,
        colors = TextFieldDefaults.textFieldColors(
            backgroundColor = colorResource(id = R.color.text_field_background),
            unfocusedIndicatorColor = when (errorStatus) {
                false -> colorResource(id = backgroundColor)
                else -> colorResource(id = R.color.text_field_error_indicator)
            },
            focusedIndicatorColor = if (errorStatus) colorResource(id = R.color.text_field_error_indicator) else Color.Transparent
            /*errorIndicatorColor = colorResource(id = R.color.text_field_error_indicator)*/
        ),
        shape = RoundedCornerShape(8.dp),
        textStyle = MaterialTheme.typography.subtitle1.copy(
            textAlign = TextAlign.Center,
            color = colorResource(id = R.color.black)
        )
    )
}

@Preview
@Composable
fun OTPTextFieldsPreview() {
    MobileBankingTheme {
        Surface {
            OTPTextFields(
                length = 6,
                code = "126",
                modifier = Modifier,
                filled = {},
                unFilled = {},
                errorStatus = false
            )
        }
    }
}
