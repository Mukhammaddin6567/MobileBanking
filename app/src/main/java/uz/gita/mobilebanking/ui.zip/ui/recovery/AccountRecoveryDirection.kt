package uz.gita.mobilebanking.ui.recovery

import uz.gita.mobilebanking.data.local.model.auth.SignUpData

interface AccountRecoveryDirection {

    fun popBackStack()
    fun navigateToVerificationScreen(data: SignUpData)

}