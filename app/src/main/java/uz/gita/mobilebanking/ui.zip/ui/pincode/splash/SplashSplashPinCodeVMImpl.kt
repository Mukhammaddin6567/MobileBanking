package uz.gita.mobilebanking.ui.pincode.splash

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import timber.log.Timber
import uz.gita.mobilebanking.domain.usecase.pincode.PinCodeUC
import uz.gita.mobilebankingMBF.R
import javax.inject.Inject

@HiltViewModel
class SplashSplashPinCodeVMImpl @Inject constructor(
    private val useCase: PinCodeUC,
    private val direction: SplashPinCodeDirection
) : ViewModel(), SplashPinCodeVM {

    private val _state = MutableStateFlow(SplashPinCodeContract.State())
    override val state: StateFlow<SplashPinCodeContract.State> = _state.asStateFlow()
    private var effect: ((SplashPinCodeContract.SideEffect) -> Unit)? = null

    init {
        viewModelScope.launch {
            useCase.checkFingerPrintState().collectLatest { state ->
                if (state) effect?.invoke(SplashPinCodeContract.SideEffect.FINGER_PRINT)
            }
        }
    }

    override fun sideEffect(sideEffect: (SplashPinCodeContract.SideEffect) -> Unit) {
        effect = sideEffect
    }

    override fun onEvent(event: SplashPinCodeContract.Event) {
        when (event) {
            is SplashPinCodeContract.Event.EnterCode -> {
                useCase
                    .checkPinCode(event.code)
                    .onEach { isMatches ->
                        Timber.d("onEvent: $isMatches")
                        if (isMatches) direction.navigateToMainScreen()
                        else {
                            reduce {
                                it.copy(
                                    textPinCode = R.string.text_pin_code_error,
                                    isError = isMatches
                                )
                            }
                            delay(500)
                            reduce {
                                it.copy(
                                    textPinCode = R.string.text_pin_code_enter,
                                    isError = !isMatches
                                )
                            }
                        }
                    }
                    .launchIn(viewModelScope)
            }
            is SplashPinCodeContract.Event.FingerPrint -> effect?.invoke(SplashPinCodeContract.SideEffect.FINGER_PRINT)
        }
    }

    private fun reduce(content: (old: SplashPinCodeContract.State) -> SplashPinCodeContract.State) {
        val oldState = _state
        val newState = content(oldState.value)
        _state.value = newState
    }

}