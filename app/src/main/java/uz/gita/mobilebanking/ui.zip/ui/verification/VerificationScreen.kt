package uz.gita.mobilebanking.ui.verification

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.lifecycle.viewmodel.compose.viewModel
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.data.local.model.auth.SignUpData
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.convertLongToTime
import uz.gita.mobilebanking.utils.customui.*
import uz.gita.mobilebankingMBF.R

@Parcelize
class VerificationScreen(
    override val screenKey: String = uniqueScreenKey,
    private val data: SignUpData,
) : ComposeScreen(id = "VerificationScreen") {

    @Composable
    override fun Content() {
        val viewModel: VerificationVM = viewModel<VerificationVMImpl>()
        viewModel.initData(data)
        VerificationScreenContent(viewModel.state.collectAsState(), viewModel::onEvent)
    }

}

@Composable
private fun VerificationScreenContent(
    state: State<VerificationContract.State>,
    event: (VerificationContract.Event) -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize()) {
        ConstraintLayout {
            val (title, textSentNumber, boxCode, textTimer, progress, buttonAccept, keyboard) = createRefs()
            var code by remember { mutableStateOf("") }
            val length by remember { mutableStateOf(6) }

            Row(modifier = Modifier
                .padding(start = 16.dp, end = 16.dp)
                .constrainAs(title) {
                    top.linkTo(parent.top, margin = 16.dp)
                    linkTo(start = parent.start, end = parent.end)
                }) {
                BackButton(onClick = { event(VerificationContract.Event.OnBackPressed) })
                AuthTitle(
                    text = R.string.text_accept,
                    modifier = Modifier.weight(1f)
                )
                EmptyButton()
            }

            /*Text(
                text = stringResource(id = R.string.text_accept),
                modifier =
                Modifier
                    .constrainAs(textTitle) {
                        start.linkTo(parent.start)
                        end.linkTo(parent.end)
                        top.linkTo(parent.top, margin = 16.dp)
                    },
                fontSize = 20.sp,
                color = colorResource(id = R.color.color_verification_title),
                style = MaterialTheme.typography.subtitle1*/
//            )

//            if (state.value.phoneNumber.isNotEmpty()) {
            Text(
                text = stringResource(
                    id = R.string.text_phone_number_sent,
                    state.value.phoneNumber
                ),
                modifier = Modifier
                    .constrainAs(textSentNumber) {
                        linkTo(parent.top, parent.bottom, bias = 0.1625f)
                        linkTo(parent.start, parent.end)
                    },
                style = MaterialTheme.typography.subtitle2.copy(
                    color = colorResource(id = R.color.text_light_black),
                    textAlign = TextAlign.Center
                )
            )
//            }

            OTPTextFields(
                length = length,
                code = code,
                modifier = Modifier
                    .padding(32.dp)
                    .constrainAs(boxCode) {
                        linkTo(parent.top, parent.bottom, bias = 0.29375f)
                        linkTo(parent.start, parent.end)
                    },
                filled = { event(VerificationContract.Event.Filled) },
                unFilled = { event(VerificationContract.Event.UnFilled) },
                errorStatus = state.value.errorStatus
            )

            if (!state.value.progressStatus) {
                Box(modifier = Modifier
                    .constrainAs(textTimer) {
                        linkTo(parent.start, parent.end)
                        linkTo(parent.top, parent.bottom, bias = 0.4f)
                    }) {
                    when (state.value.errorStatus) {
                        false -> {
                            if (state.value.timerStatus) {
                                Text(
                                    text = convertLongToTime(state.value.timer),
                                    style = MaterialTheme.typography.subtitle2.copy(
                                        lineHeight = 22.sp,
                                    )
                                )
                            } else {
                                AuthTextButton(
                                    onClick = { event(VerificationContract.Event.Retry) },
                                    text = R.string.text_resend
                                )
                            }
                        }
                        else -> {
                            Text(
                                text = state.value.message,
                                style = MaterialTheme.typography.subtitle2.copy(
                                    color = colorResource(id = R.color.text_red),
                                    lineHeight = 22.sp,
                                )
                            )
                        }

                    }
                }
            }

            if (state.value.progressStatus) {
                CircularProgressIndicator(modifier = Modifier.constrainAs(progress) {
                    linkTo(parent.start, parent.end)
                    top.linkTo(boxCode.bottom)
                    bottom.linkTo(buttonAccept.top)
                })
            }

            AuthButton(
                onClick = { event(VerificationContract.Event.OnRegister(code = code)) },
                modifier = Modifier
                    .padding(start = 16.dp, end = 16.dp)
                    .constrainAs(buttonAccept) {
                        linkTo(parent.start, parent.end)
                        bottom.linkTo(keyboard.top, margin = 16.dp)
                    },
                enabled = state.value.acceptButtonStatus,
                text = R.string.text_accept
            )

            OTPKeyboard(
                numberOnClick = { digit ->
                    if (state.value.isKeyboardEnabled) {
                        if (code.length >= length) return@OTPKeyboard
                        code += digit
                    }
                },
                clearOnClick = {
                    event(VerificationContract.Event.ActionKeyboard)
                    if (state.value.isKeyboardEnabled) code = ""
                },
                backSpaceOnClick = {
                    event(VerificationContract.Event.ActionKeyboard)
                    if (state.value.isKeyboardEnabled) {
                        if (code.isNotEmpty()) code =
                            code.substring(0, code.length - 1)
                    }
                },
                modifier = Modifier
                    .fillMaxHeight(0.38125f)
                    .constrainAs(keyboard) {
                        bottom.linkTo(parent.bottom)
                    }
            )
        }
    }
}

@SuppressLint("UnrememberedMutableState")
@Preview
@Composable
private fun VerificationScreenPreview() {
    MobileBankingTheme {
        VerificationScreenContent(
            state = mutableStateOf(VerificationContract.State()), event = {})
    }
}
