package uz.gita.mobilebanking.ui.language

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import timber.log.Timber
import uz.gita.mobilebanking.domain.usecase.language.LanguageUC
import javax.inject.Inject

@HiltViewModel
class LanguageVMImpl @Inject constructor(
    private val languageUC: LanguageUC,
    private val direction: LanguageDirection
) : ViewModel(), LanguageVM {

    private var _state = MutableStateFlow(LanguageContract.State(currentLanguage = ""))
    override val state = _state.asStateFlow()

    init {
        languagesList()
        currentLanguage()
    }

    override fun onEvent(event: LanguageContract.Event) {
        Timber.d("onEvent started")
        when (event) {
            is LanguageContract.Event.AcceptLanguage -> {
                Timber.d("onEvent: ${event.language}")
                viewModelScope.launch {
                    languageUC
                        .setAppLanguage(event.language)
                        .collectLatest { language -> reduce { it.copy(currentLanguage = language) } }
                    delay(250)
                    direction.navigateToPrivacyPolicyScreen()
                }
            }
        }
        Timber.d("onEvent finished")
    }

    private fun languagesList() {
        viewModelScope.launch {
            languageUC
                .getAppLanguages()
                .collectLatest { list -> reduce { it.copy(languages = list) } }
        }
    }

    private fun currentLanguage() {
        viewModelScope.launch {
            languageUC
                .currentLanguage()
                .collectLatest { language -> reduce { it.copy(currentLanguage = language) } }
        }
    }

    private fun reduce(content: (old: LanguageContract.State) -> LanguageContract.State) {
        val oldState = _state.value
        val newState = content(oldState)
        _state.value = newState
    }
}