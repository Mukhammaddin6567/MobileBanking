package uz.gita.mobilebanking.ui.privacy

interface PrivacyPolicyDirection {

    fun navigateToSignInScreen()

}