package uz.gita.mobilebanking.ui.recovery

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.customui.*
import uz.gita.mobilebanking.utils.isPhoneNumber
import uz.gita.mobilebanking.utils.phoneNumberFilter
import uz.gita.mobilebankingMBF.R

@Parcelize
class AccountRecoveryScreen(override val screenKey: String = uniqueScreenKey) :
    ComposeScreen("AccountRecoveryScreen") {

    @Composable
    override fun Content() {
        val viewModel: AccountRecoveryVM = viewModel<AccountRecoveryVMImpl>()
        AccountRecoveryContent(viewModel.state.collectAsState(), viewModel::onEvent)
    }
}

@Composable
private fun AccountRecoveryContent(
    state: State<AccountRecoveryContract.State>,
    event: (AccountRecoveryContract.Event) -> Unit
) {
    Surface(modifier = Modifier.fillMaxSize()) {
        Column(Modifier.padding(16.dp)) {
            var textPhoneNumber by remember { mutableStateOf("+998") }
            var phoneNumberStatus by remember { mutableStateOf(false) }
            val focusManager = LocalFocusManager.current

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                BackButton(onClick = {
                    if (state.value.isBackButtonEnabled) event(
                        AccountRecoveryContract.Event.OnBackPressed
                    )
                }, modifier = Modifier)
                AuthTitle(modifier = Modifier.weight(1f), text = R.string.text_account_recovery)
                EmptyButton()
            }

            Text(
                modifier = Modifier.padding(top = 64.dp),
                text = stringResource(id = R.string.text_account_recovery_description),
                style = MaterialTheme.typography.body2.copy(
                    lineHeight = 22.sp
                )
            )

            AuthOutlinedTextField(
                modifier = Modifier.padding(top = 32.dp),
                caption = R.string.text_phone_number,
                value = textPhoneNumber,
                onValueChange = { phone ->
                    if (phone.length > 13) return@AuthOutlinedTextField
                    phoneNumberStatus = isPhoneNumber(phone)
                    textPhoneNumber = phone
                },
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Phone,
                    imeAction = ImeAction.Done
                ),
                keyboardActions = KeyboardActions(onDone = {
                    focusManager.clearFocus()
                }),
                visualTransformation = { phoneNumberFilter(it) }
            )

            when (state.value.isProgress) {
                true -> CircularProgressIndicator(
                    modifier = Modifier
                        .weight(1f)
                        .align(alignment = Alignment.CenterHorizontally)
                        .wrapContentHeight(align = Alignment.CenterVertically)
                )
                else -> Spacer(modifier = Modifier.weight(1f))
            }

            AuthButton(
                onClick = { event(AccountRecoveryContract.Event.Send(textPhoneNumber)) },
                modifier = Modifier,
                enabled = phoneNumberStatus && state.value.isSendButtonEnabled,
                text = R.string.text_send
            )
        }
    }
}

@SuppressLint("UnrememberedMutableState")
@[Preview Composable]
private fun AccountRecoveryPreview() {
    MobileBankingTheme {
        AccountRecoveryContent(state = mutableStateOf(AccountRecoveryContract.State()), event = {})
    }
}