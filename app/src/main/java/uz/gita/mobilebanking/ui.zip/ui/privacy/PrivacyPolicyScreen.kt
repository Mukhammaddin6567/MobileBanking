package uz.gita.mobilebanking.ui.privacy

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.customui.AppIcon
import uz.gita.mobilebanking.utils.customui.AuthButton
import uz.gita.mobilebanking.utils.customui.AuthTitle
import uz.gita.mobilebanking.utils.customui.CircleCheckBox
import uz.gita.mobilebankingMBF.R

@Parcelize
class PrivacyPolicyScreen(override val screenKey: String = uniqueScreenKey) :
    ComposeScreen(id = "PrivacyPolicyScreen") {

    @Composable
    override fun Content() {
        val viewModel: PrivacyPolicyVM = viewModel<PrivacyPolicyVMImpl>()
        PrivacyPolicyContent(viewModel.state.collectAsState(), viewModel::onEvent)
    }

}

@Composable
private fun PrivacyPolicyContent(
    state: State<PrivacyPolicyContract.State>,
    event: (PrivacyPolicyContract.Event) -> Unit
) {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {

        AuthTitle(
            modifier = Modifier.padding(top = 16.dp),
            text = R.string.text_policy
        )

        AppIcon(
            modifier = Modifier
                .padding(start = 16.dp, top = 48.dp),
            color = colorResource(id = R.color.black),
        )

        Text(
            modifier = Modifier
                .padding(start = 16.dp, top = 16.dp),
            text = stringResource(id = R.string.text_policy_service),
            style = MaterialTheme.typography.body1.copy(
                fontSize = 16.sp
            )
        )

        Text(
            modifier = Modifier
                .padding(start = 16.dp, end = 16.dp, top = 8.dp),
            text = stringResource(id = R.string.text_policy_details),
            style = MaterialTheme.typography.subtitle2,
        )

        Row(
            modifier = Modifier
                .padding(start = 16.dp, top = 16.dp, bottom = 26.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            CircleCheckBox(
                checked = state.value.buttonAcceptStatus,
                onCheckedChange = { event(PrivacyPolicyContract.Event.CHECK) },
            )
            Text(
                modifier = Modifier.padding(start = 10.dp),
                text = stringResource(id = R.string.text_policy_agreement),
                style = MaterialTheme.typography.body2.copy(
                    color = colorResource(id = R.color.text_green),
                    fontSize = 14.sp,
                    lineHeight = 18.sp
                )
            )
        }

        AuthButton(
            onClick = { event(PrivacyPolicyContract.Event.ACCEPT) },
            modifier = Modifier
                .padding(start = 16.dp, end = 16.dp, bottom = 32.dp),
            enabled = state.value.buttonAcceptStatus,
            text = R.string.text_accept
        )

    }
}


@SuppressLint("UnrememberedMutableState")
@[Preview Composable]
private fun PrivacyPolicyPreview() {
    MobileBankingTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            PrivacyPolicyContent(mutableStateOf(PrivacyPolicyContract.State())) {}
        }
    }
}