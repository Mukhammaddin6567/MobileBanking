package uz.gita.mobilebanking.ui.verification

interface VerificationDirection {

    fun popBackStack()

    fun navigateToRegisterPinCodeScreen()

}