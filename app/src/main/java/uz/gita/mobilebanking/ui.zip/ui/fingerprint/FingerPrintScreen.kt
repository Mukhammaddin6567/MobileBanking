package uz.gita.mobilebanking.ui.fingerprint

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.customui.AuthButton
import uz.gita.mobilebanking.utils.customui.BackButton
import uz.gita.mobilebankingMBF.R

@Parcelize
class FingerPrintScreen(override val screenKey: String = uniqueScreenKey) :
    ComposeScreen(id = "FingerPrintScreen") {

    @Composable
    override fun Content() {
        // val viewmodel : FingerPrintVM = viewModel<FingerPrintVMImpl>()

        FingerPrintContent()
    }

}

@Composable
private fun FingerPrintContent() {
    ConstraintLayout(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                start = 16.dp,
                end = 16.dp,
                top = 16.dp,
                bottom = 32.dp
            )
    ) {
        val (skipButton, fingerPrintImage, textsColumn, agreementRow, acceptButton) = createRefs()
        val buttonStatus = false
        var switchState by remember { mutableStateOf(false) }
        BackButton(onClick = { /*TODO*/ })

        Text(
            text = when (buttonStatus) {
                false -> stringResource(id = R.string.text_skip)
                else -> stringResource(id = R.string.text_ready)
            },
            modifier = Modifier
                .clickable {}
                .constrainAs(skipButton) {
                    end.linkTo(parent.end)
                },
            style = MaterialTheme.typography.body1
        )

        Image(
            modifier = Modifier
                .constrainAs(fingerPrintImage) {
                    linkTo(start = parent.start, end = parent.end)
                    linkTo(top = parent.top, bottom = parent.bottom, bias = 0.15f)
                }
                .width(64.dp)
                .height(64.dp),
            painter = when (buttonStatus) {
                false -> painterResource(id = R.drawable.ic_fingerprint_default)
                else -> painterResource(id = R.drawable.ic_fingerprint_checked)
            },
            contentDescription = ""
        )

        Column(
            modifier = Modifier
                .constrainAs(textsColumn) {
                    linkTo(start = parent.start, end = parent.end)
                    linkTo(top = parent.top, bottom = parent.bottom, bias = 0.3f)
                },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(id = R.string.text_finger_print),
                style = MaterialTheme.typography.body2.copy(
                    textAlign = TextAlign.Center,
                    fontSize = 24.sp
                )
            )
            Text(
                modifier = Modifier
                    .padding(top = 16.dp),
                text = stringResource(id = R.string.text_finger_print_description),
                style = MaterialTheme.typography.subtitle2.copy(
                    color = colorResource(id = R.color.text_light_black),
                    textAlign = TextAlign.Center
                )
            )
        }

        if (buttonStatus) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .constrainAs(agreementRow) {
                        linkTo(start = parent.start, end = parent.end)
                        top.linkTo(textsColumn.bottom)
                        bottom.linkTo(acceptButton.top)
                    }) {
                Text(
                    modifier = Modifier.weight(1f),
                    text = stringResource(id = R.string.text_finger_print_agreement),
                    style = MaterialTheme.typography.body2
                )
                Switch(
                    checked = switchState,
                    onCheckedChange = { switchState = !switchState },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = colorResource(id = R.color.icon_green),
                        uncheckedThumbColor = colorResource(id = R.color.icon_white)
                    )
                )
            }


            AuthButton(
                onClick = { },
                modifier = Modifier.constrainAs(acceptButton) {
                    bottom.linkTo(parent.bottom)
                },
                enabled = true,
                text = R.string.text_continue
            )
        } else {
            Text(
                modifier = Modifier
                    .clickable { }
                    .constrainAs(acceptButton) {
                        linkTo(start = parent.start, end = parent.end)
                        bottom.linkTo(parent.bottom)
                    },
                text = stringResource(id = R.string.text_turn_on),
                style = MaterialTheme.typography.body1.copy(color = colorResource(id = R.color.text_green))
            )

        }


    }
}

@[Preview Composable]
private fun FingerPrintPreview() {
    MobileBankingTheme {
        Surface {
            FingerPrintContent()
        }
    }
}