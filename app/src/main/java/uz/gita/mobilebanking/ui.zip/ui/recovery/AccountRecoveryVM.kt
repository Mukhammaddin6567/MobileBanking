package uz.gita.mobilebanking.ui.recovery

import kotlinx.coroutines.flow.StateFlow

interface AccountRecoveryVM {

    val state: StateFlow<AccountRecoveryContract.State>

    fun onEvent(event: AccountRecoveryContract.Event)

}