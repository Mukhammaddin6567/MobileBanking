package uz.gita.mobilebanking.ui.pincode.register

interface RegisterPinCodeDirection {

    fun navigateToMainScreen()

    fun navigateToFingerPrintScreen()

}