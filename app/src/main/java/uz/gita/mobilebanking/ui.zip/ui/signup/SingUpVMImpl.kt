package uz.gita.mobilebanking.ui.signup

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import timber.log.Timber
import uz.gita.mobilebanking.data.local.model.auth.SignUpData
import uz.gita.mobilebanking.data.local.model.auth.onResource
import uz.gita.mobilebanking.data.local.model.auth.onSuccess
import uz.gita.mobilebanking.data.local.model.auth.onText
import uz.gita.mobilebanking.domain.usecase.signup.SignUpUC
import uz.gita.mobilebanking.utils.toPhoneNumberAPI
import javax.inject.Inject

@HiltViewModel
class SingUpVMImpl @Inject constructor(
    private val useCase: SignUpUC,
    private val direction: SignUpDirection
) : ViewModel(), SignUpVM {

    private var _state = MutableStateFlow(SignUpContract.State())
    override val state: StateFlow<SignUpContract.State> = _state.asStateFlow()
    private var effect: ((sideEffect: SignUpContract.SideEffect) -> Unit)? = null

    override fun onEvent(event: SignUpContract.Event) {
        when (event) {
            is SignUpContract.Event.Registration -> {
                Timber.d("onEvent: $event")
                reduce {
                    it.copy(
                        isProgress = true,
                        isActiveRegisterButton = false,
                        isBackButtonEnabled = false,
                        isSignInButtonEnabled = false
                    )
                }
                val data = SignUpData(
                    firstname = event.firstName,
                    lastname = event.lastName,
                    phoneNumber = toPhoneNumberAPI(event.phoneNumber),
                    password = event.password
                )
                useCase
                    .signUp(data)
                    .onEach { resultData ->
                        resultData.onSuccess {
                            Timber.d("sign up onSuccess")
                            direction.navigateToVerificationScreen(data)
                            setDefaultState()
                        }
                        resultData.onText {
                            Timber.d("sign up onText: $message")
                            effect?.invoke(SignUpContract.SideEffect.OnText(message))
                            setDefaultState()
                        }
                        resultData.onResource {
                            Timber.d("sign up onResource: $resourceId")
                            effect?.invoke(
                                SignUpContract.SideEffect.OnResource(
                                    resourceId
                                )
                            )
                            setDefaultState()
                        }
                    }.launchIn(viewModelScope)

            }
            is SignUpContract.Event.OnBackPressed -> {
                setDefaultState()
                direction.popBackStack()
            }
        }
    }

    override fun sideEffect(sideEffect: (sideEffect: SignUpContract.SideEffect) -> Unit) {
        effect = sideEffect
    }


    private fun reduce(content: (old: SignUpContract.State) -> SignUpContract.State) {
        val oldState = _state.value
        val newState = content(oldState)
        _state.value = newState
    }

    private fun setDefaultState() {
        _state.value = SignUpContract.State()
    }

}