package uz.gita.mobilebanking.ui.pincode.splash

import kotlinx.coroutines.flow.StateFlow

interface SplashPinCodeVM {

    val state: StateFlow<SplashPinCodeContract.State>

    fun sideEffect(sideEffect: (SplashPinCodeContract.SideEffect) -> Unit)

    fun onEvent(event: SplashPinCodeContract.Event)

}