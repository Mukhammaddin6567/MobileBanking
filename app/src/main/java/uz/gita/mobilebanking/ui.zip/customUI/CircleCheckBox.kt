package uz.gita.mobilebanking.utils.customui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import uz.gita.mobilebankingMBF.R

@Composable
fun CircleCheckBox(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var isChecked by remember { mutableStateOf(checked) }
    Image(
        painter = when (isChecked) {
            false -> painterResource(id = R.drawable.ic_circle_unchecked)
            else -> painterResource(id = R.drawable.ic_circle_checked)
        },
        contentDescription = "AppCheckBox",
        modifier = modifier
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = rememberRipple(bounded = false), // You can also change the color and radius of the ripple
                onClick = {
                    isChecked = !isChecked
                    onCheckedChange.invoke(isChecked)
                }
            )
    )
}