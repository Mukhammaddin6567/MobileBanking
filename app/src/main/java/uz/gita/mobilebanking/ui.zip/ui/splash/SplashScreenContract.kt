package uz.gita.mobilebanking.ui.splash

class SplashScreenContract {

    data class State(val language: String = "")

}