package uz.gita.mobilebanking.ui.test

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.OutlinedTextField
import androidx.compose.material.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.customui.AuthOutlinedTextField
import uz.gita.mobilebanking.utils.phoneNumberFilter
import uz.gita.mobilebankingMBF.R

@Parcelize
class TestScreen(override val screenKey: String = uniqueScreenKey) :
    ComposeScreen(id = "TestScreen") {

    @Composable
    override fun Content() {
        TestScreenContent()
    }

}

@Composable
private fun TestScreenContent() {
    Surface(modifier = Modifier.fillMaxSize()) {

    }
}

@[Preview Composable]
private fun TestScreenPreview() {
    MobileBankingTheme {
        TestScreenContent()
    }
}