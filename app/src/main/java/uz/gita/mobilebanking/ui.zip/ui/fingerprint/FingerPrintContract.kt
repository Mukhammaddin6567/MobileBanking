package uz.gita.mobilebanking.ui.fingerprint

import uz.gita.mobilebankingMBF.R

class FingerPrintContract {

    data class State(
        val buttonAcceptState: Boolean = false,
        val textSkipButton: Int = R.string.text_skip
    )

}