package uz.gita.mobilebanking.ui.language

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.lifecycle.viewmodel.compose.viewModel
import com.github.terrakok.modo.android.compose.ComposeScreen
import com.github.terrakok.modo.android.compose.uniqueScreenKey
import kotlinx.parcelize.Parcelize
import uz.gita.mobilebanking.data.local.model.AppLanguage
import uz.gita.mobilebanking.ui.theme.MobileBankingTheme
import uz.gita.mobilebanking.utils.SetLanguage
import uz.gita.mobilebanking.utils.customui.AppIcon
import uz.gita.mobilebanking.utils.customui.ListItemPicker
import uz.gita.mobilebankingMBF.R

@Parcelize
class LanguageScreen(override val screenKey: String = uniqueScreenKey) :
    ComposeScreen(id = "LanguageScreen") {

    @Composable
    override fun Content() {
        val viewModel: LanguageVM = viewModel<LanguageVMImpl>()
        LanguageContent(
            state = viewModel.state.collectAsState(),
            event = viewModel::onEvent
        )
    }

}

@Composable
private fun LanguageContent(
    state: State<LanguageContract.State>,
    event: (event: LanguageContract.Event) -> Unit,
) {
    ConstraintLayout(modifier = Modifier.fillMaxSize()) {
        val (title, listPicker) = createRefs()
        val topGuideLineTitle = createGuidelineFromTop(0.15f)
        val topGuideLineLanguage = createGuidelineFromTop(0.45f)

        AppIcon(
            modifier = Modifier
                .constrainAs(title) {
                    start.linkTo(parent.start)
                    end.linkTo(parent.end)
                    top.linkTo(topGuideLineTitle)
                },
            color = colorResource(id = R.color.black)
        )

        if (state.value.languages.isNotEmpty()) {
            val listOfLanguages by remember { mutableStateOf(state.value.languages) }
            var selectedLanguage by remember { mutableStateOf(listOfLanguages[1]) }

            SetLanguage(language = state.value.currentLanguage)

            ListItemPicker(
                value = selectedLanguage,
                list = listOfLanguages,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 30.dp, end = 30.dp)
                    .constrainAs(listPicker) {
                        start.linkTo(parent.start)
                        end.linkTo(parent.end)
                        top.linkTo(topGuideLineLanguage)
                    },
                onValueChange = {
                    selectedLanguage = it
                },
                onClickLanguage = { language ->
                    event(LanguageContract.Event.AcceptLanguage(language))
                }
            )
        }
    }
}

@SuppressLint("UnrememberedMutableState")
@[Preview Composable]
private fun LanguagePreview() {
    MobileBankingTheme {
        Surface(modifier = Modifier.fillMaxSize()) {
            LanguageContent(
                state = mutableStateOf(
                    LanguageContract.State(
                        currentLanguage = "",
                        languages = listOf(
                            AppLanguage.RU.value,
                            AppLanguage.UZ.value,
                            AppLanguage.EN.value
                        ),
                    )
                ),
                event = {})
        }
    }
}
