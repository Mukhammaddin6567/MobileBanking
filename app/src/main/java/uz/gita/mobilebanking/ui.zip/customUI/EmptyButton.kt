package uz.gita.mobilebanking.utils.customui

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.padding
import androidx.compose.material.ripple.rememberRipple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import uz.gita.mobilebankingMBF.R

@Composable
fun EmptyButton(
) {
    Image(
        painterResource(id = R.drawable.ic_empty),
        contentDescription = ""
    )
}