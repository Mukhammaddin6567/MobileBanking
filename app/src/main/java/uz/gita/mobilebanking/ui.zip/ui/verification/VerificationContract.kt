package uz.gita.mobilebanking.ui.verification

class VerificationContract {

    data class State(
        val isKeyboardEnabled: Boolean = true,
        val progressStatus: Boolean = false,
        val timerStatus: Boolean = true,
        val errorStatus: Boolean = false,
        val acceptButtonStatus: Boolean = false,
        val phoneNumber: String = "",
        val timer: Long = 60000L,
        val message: String = "",
        val resourceId: Int = 0
    )

    sealed class Event {
        object OnBackPressed : Event()
        object Filled : Event()
        object UnFilled : Event()
        object Retry : Event()
        object ActionKeyboard : Event()
        data class OnRegister(val code: String) : Event()
    }

}